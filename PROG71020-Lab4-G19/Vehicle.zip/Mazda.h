#pragma once
#include "Vehicle.h"
class Mazda :public Vehicle
{
public:
	void Draw()
	{

	}
	void Drive()
	{

	}
};

