#pragma once
#include "Drawable.h"
class Vehicle
{
public:
	virtual void Draw() 
	{

	}

	virtual void Drive()
	{

	}

};

