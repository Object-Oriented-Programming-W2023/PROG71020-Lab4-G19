#pragma once
#include <iostream>
#include "Shape.h"
double getTotalArea(Shape* arr[]);
