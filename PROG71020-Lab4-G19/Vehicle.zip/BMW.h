#pragma once
#include "Vehicle.h"
class BMW:public Vehicle
{
public:
	void Draw()
	{

	}
	void Drive()
	{

	}
};

